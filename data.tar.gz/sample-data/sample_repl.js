import {
    createRequire
}from 'module'

import schema from '../tuits/tuits-schema.js'
// import model from '../tuits/tuits-model.js'
// import * as dao from '../tuits/tuits-dao.js'
import mongoose from 'mongoose';
import tuitsModel from "../tuits/tuits-model.js";

const {log} = console
;(async ()=>{
    const require = createRequire(import.meta.url)
    const abcde = ['a','b','c','d','e'].map(e=> require(`./${e}.json`))
    const  con =await mongoose.connect(
        'mongodb+srv://samraphael:dbPass2@tuiter-app.lwsp4.mongodb.net/myFirstDatabase?retryWrites=true&w=majority'
    );

    // await mongoose.connect ('mongodb://localhost:27017/webdev');
    const [a,b,c,d,e] = abcde;
    // await abcde.forEach(async record=>{
    //     const z = await dao.createTuit(record)
    //     console.log(z)
    // })
    await abcde.forEach(async (doc)=>{
        const created = await tuitsModel.create(doc)
        console.log(created)
    })

    // const one = await tuitsModel.find({postedBy:{username:"Anonymouse"}})
    // for (let x  in one){
    //     console.log(await tuitsModel.deleteOne({_id: x._id}))
    // }
    // const two = await tuitsModel.find({postedBy:{username:"Anonymouse"}})
    // console.log(two)
     // const modeldata =  await tuitsModel.find()
    // console.log(modeldata)
    // await abcde.forEach(createTuit)
    // for (let i in abcde){
    //     try{
    //         await createTuit(i)
    //     console.log(i._id)
    //     }catch(err){
    //
    //     console.log("failure on ",i._id)
    //     }
    //
    // }
    // const all = await findAllTuits()
    //
    //     log("all, " ,all.length)
    // console.log(...all)

})()

// const  c = mongoose. connect ('mongodb://localhost:27017/webdev');
// console.log(c)
// c.then(e=>console.log(e))
//
// ;(async()=>{
//     console.log(await mongoose.modelNames())
//     const find =await tuitsModel.find()
//     console.log(find)
// })


